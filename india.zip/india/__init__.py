from .goa.beach import beach
from .kerala.info import animal
