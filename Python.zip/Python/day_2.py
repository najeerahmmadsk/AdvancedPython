# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 09:30:29 2019

@author: Administrator
"""

a = ["najeer", "ahmmad", "hari", "ravi"]
#sort base length
sorted(a)
sorted(a, key=len)

b=[(22,21,20),(24,25,20),(18,17,19),(10,12,18)]
#sort based on total
print(sorted(b,key=sum))
#sort based on average marks
print(sorted(b, key=lambda x:sum(x)/len(x))) 

c=["anaya", "najeer", "hari", "najeer ahmmad"]
print(sorted(c, key=lambda x:x.count("a")))
print(sorted(c,key=str.lower))

#map, filtter, reduce
#map ------------------------------
print(map(len,c))
print(list(map(len,c)))
print(list(map(str.upper,c)))

d=[5,6,7,3,9,8]
def square(x):
    return x*x
#with using fuction
print(list(map(square,d)))
#using lambda fucnctions
print(list(map(lambda x:x*x*x,d)))
#multiple value returns
def scube(x):
    return x**2,x**3
print(list(map(scube,d)))

## filtters ---------------------
e=["anaya", "najeer", "hari", "najeer ahmmad"]
print(list(filter(lambda x:len(x)==4,e)))
print(list(filter(lambda x:x.count('a')>1,e)))
#filtter even numbers
ef=[5,6,7,3,9,8]
print(list(filter(lambda x:x%2==0,ef)))

#reduce ------------------------
from functools import reduce
f=[5,6,7,3,9,8]
print(reduce(lambda x,y:x+y,f))
print(reduce(lambda x,y:x*y,f))

#decrators ------------------ 
def double(old_fun):
    def new_fun():
        print(1111111111)
        old_fun()
        print(2222222222)
        old_fun()
    return new_fun

@double
def wish():
    print("hello")

wish()

#out put modify
def double_out(old_fun):
    def new_fun(x):
        return 2 * old_fun(x)
    return new_fun

@double_out
def square(x):
    return x*x

print(square(4))

#input modify
def double_in(old_fun):
    def new_fun(x):
        return old_fun(2*x)
    return new_fun

@double_in
def square(x):
    return x*x

print(square(4))

#closures -------------
def convert(x):
    print(x)
    def abc(y):
        print("---")
        print(y)
        return x*y
    return abc
mm=convert(1000)
cm=convert(100)
km=convert(0.001)
print(mm(54))
print(cm(54))
print(km(54))

def divide(a,b):
    try:
        print(a/b)
    except ZeroDivisionError:
        print("check your denom")

divide(4,2)

def divide(a,b):
    try:
        print(a/b)
    except Exception as err:
        print("check your denom")
        print(err, type(err))
    finally:
        print("Done")
divide(4,2)
divide(4,0)
divide('a','b')


def factorial(n):
    if n<0:
        myexp = ValueError("-ve not allowed")
        raise myexp
    else:
        f=1
        for x in range(2,n+1):
            f*=x
        return f
    
print(factorial(3))
print(factorial(10))
print(factorial(0))
print(factorial(-3))


a=[23,21,15,10,24,26,4,22]
for mark in a:
    assert mark <=25