# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 10:02:46 2019

@author: Administrator
"""


def square(x):
    return x * x
def cube(x):
    return x*x*x
print(square(3))
print(cube(3))

print(__file__)
print(__name__)
