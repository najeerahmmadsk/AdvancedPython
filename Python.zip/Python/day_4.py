# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 10:39:49 2019

@author: Administrator
"""

import subprocess
#subprocess.run("notepad")
ANA = subprocess.run(["ping", "-n", "2", "www.google.com"]).returncode
STATE = subprocess.run(["ping", "-n", "2", "www.google.com"], stdout=subprocess.PIPE).returncode
j = subprocess.check_output(["ping", "-n", "2", "www.google.com"])
print(j)
