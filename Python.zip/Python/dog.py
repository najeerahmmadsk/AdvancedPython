# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 11:28:01 2019

@author: Administrator
"""

class Dog:
    #cout =0 is class variables 
    #_count=0  private variables
    #__count=0 sudo private variables
    __count=0 #Class variables
    def __init__(self,color=None,breed=None):
        self.color=color
        self.breed=breed
        Dog.__count +=1
    @classmethod
    def get_dog_count(cls):
        print(cls.__count)
    @staticmethod
    def simple_interest(p,t,r):
        print(p*t*r/100)
    def speck(self):
        print("bhou..bhou")
    def guard(self):
        print("I am guarding")

Dog.get_dog_count()
tommy=Dog("red","hi")
Dog.get_dog_count()
tommy.get_dog_count()
tommy.simple_interest(1000,5,8)
print(type(tommy))
print(isinstance(tommy,Dog))
tommy.guard()
tommy.speck()

