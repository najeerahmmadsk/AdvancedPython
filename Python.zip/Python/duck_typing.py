# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 14:07:39 2019

@author: Administrator
"""

#duck typing
class Car:
    def __init__(self,seats=None,regno=None):
        self.seatcount=seats
        self.regno = regno
        self.passengers=[None]*4
    def __str__(self):
        return "I am a {} seater car".format(self.seatcount)
    def __len__(self):
        return self.seatcount
    def __del__(self):
        print("bye.. bye..")
    def __bool__(self):
        if self.regno:
            return True
        else:
            return False
    def __add__(self,other):
        return self.seatcount + other.seatcount
    def __sub__(self,other):
        return self.seatcount - other.seatcount
    def __setitem__(self,key,value):
        self.passengers[key]=value
    def __getitem__(self,key):
        return self.passengers[key]
        
swift = Car(5,"AP26AA4892")
innova = Car(8)
zen = Car(4)
print(swift)
#del swift
print(len(zen))
print(innova + swift)
#zen.__add__(zen,innova)
print(innova - swift)
print(bool(zen))

zen[0]="Najeer"
zen[1]="zainab"
zen[2]="zainuddin"
zen[3]="haseena"
print(zen[1])
for x in zen:
    print(x)