# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 16:39:27 2019

@author: Administrator
"""

from baby import Baby
pinky=Baby()
pinky.cry() #prints I am crying
pinky.laugh() #prints ha.. ha.. ha