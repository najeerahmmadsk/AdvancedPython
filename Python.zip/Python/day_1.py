# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

a=b=c=2
print(a,b,c)
a,b,c=2,3,4
print(a,b,c)
a=[4,5,6]
x,y,z=a
print(x,y,z)
#w,x,y,z=a

age=16
def grow1():
    global age
    print(age)
    age=age+1
    print(age)
    
grow1()
print(age)


#posotional arguments:
def add(*args):
    return sum(args)
print(add(4,5))
print(add(4,5,6,7))
print(add(4,5,7,8,9,10))

#variable length keyword arguments:
def polygon(**keys):
    print(type(keys))
    print(keys)
polygon(width=10,length=20)

#help("modules")
from math import sin,radians
print(sin(radians(90)))
print(dir(sin))

from random import randint
print(randint(3,30))


a = [1,2,3,4,5,6,7,36]
b = []
for x in a:
    b.append(x*x)
print(b)

#list of compahesion
c=[x*x for x in a]
print(c)

f = [x*x for x in a if x%2==1]
print(f)

t = ["{} X {} = {}".format(x,y,x*y) for x in range(1,11) for y in range(1,11)]
print(t)


#Dict of compahesion
d = {x:x*x for x in range(5)}
print(d)

#set compahesion
e = {x for x in range(5)}
print(e)

f = set(a)
print(f)



#lambda a,b:a+b
#lambda a,b:a*b
#lambda a="najeer":a.upper()


a = [("mahabi", 1353), ("ooty", 2240),("Manali", 5345),("Mahab", 120),("aruku", 2535)]
print(sorted(a))
#sort by altitude
print(sorted(a,key=lambda x:x[1]))
#sort by case insensitive
print(sorted(a,key=lambda x:x[0].lower()))
#sort by length
print(sorted(a,key=lambda x:len(x[0])))
#sort by length reverse
print(sorted(a,key=lambda x:len(x[0]), reverse=True))