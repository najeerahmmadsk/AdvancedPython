# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 14:05:34 2019

@author: Administrator
"""

class HeadAche(Exception):
    pass
raise HeadAche("Too much python")