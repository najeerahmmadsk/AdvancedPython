# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 12:29:04 2019

@author: Administrator
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 11:28:01 2019

@author: Administrator
"""

class Dog:
    def __init__(self,color=None,breed=None):
        self.color=color
        self.breed=breed
        
    def speck(self):
        print("bhou..bhou")
    def guard(self):
        print("I am guarding")
        
class Cat:
    def speck(self):
        print("meau..meau")
    def likes(self):
        print("milk")



class WatchDog(Dog,Cat): #order of classes
    def speck(self): #access override method
        print("sub class ....")
    def pspeck(self):
        super().speck() #access overwritten method
tommy=WatchDog()
tommy.pspeck()
tommy.guard()
tommy.likes()