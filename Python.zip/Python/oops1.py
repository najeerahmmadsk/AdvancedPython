# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 15:56:25 2019

@author: Administrator
"""

class Dog:
    def __init__(self,color,breed):
        self.color=color
        self.breed=breed
    def speck(self):
        print("bhou..bhou")
    def guard(self):
        print("I am guarding")

tommy=Dog("red","hi")
print(type(tommy))
print(isinstance(tommy,Dog))
tommy.guard()
tommy.speck()


