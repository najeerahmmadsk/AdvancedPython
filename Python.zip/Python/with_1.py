# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 17:12:07 2019

@author: Administrator
"""

class CoffeeCup:
    def __enter__(self):
        print("Can i have my coffee cup")
    def __exit__(self,type,value,traceback):
        print("exitint: Here is ur coffee")
        print(type,value,traceback)
with CoffeeCup() as j:
    raise ValueError("Bad coffee")
    print("The coffee is good")