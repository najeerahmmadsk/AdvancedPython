# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 15:17:02 2019

@author: Administrator
"""

from openpyxl import Workbook
wb = Workbook()
sheet = wb.active

sheet.title = "My sheet"
sheet["A1"] = "Hello"
sheet["B1"] = "Hello2"
sheet.cell(row=2,column=5,value="hyd")
sheet.append([98,52,15,25,77])
sheet.append([98,52,15,25,77])
wb.save("sample.xlsx")

from openpyxl import load_workbook

lb = load_workbook("sample.xlsx")
print(lb.sheetnames)

sheet = wb.get_sheet_by_name('My sheet')
print(sheet.max_row,sheet.max_column)

# read from cell
print(sheet.cell(row=1,column=1).value)

# read from row
row = sheet[3]

# read from cell

for x in sheet.values:
    print(x)