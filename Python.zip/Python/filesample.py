# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 10:23:54 2019

@author: Administrator
"""

from fileinfo import FileInfo
f = FileInfo("mymodule.py")
f.getsize()
f.getlinecount()
f.firstline()
f.lastline()
f.nthline(3)
f.search("self")
f.close()
