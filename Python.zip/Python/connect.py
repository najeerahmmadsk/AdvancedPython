# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 17:34:00 2019

@author: Administrator
"""

import sqlite3
class Connect:
    def __init__(self,host,user,pass1):
        self.host=host
        self.user=user
        self.pass1=pass1
    def __enter__(self):
        self.conn = sqlite3.connect("abcd.db")
        print("connected")
    def __exit__(self,type,value,traceback):
        self.conn.close()
        print("disconnected")

with Connect("localhost", "user1","pass1") as c:
    print("starting")
    print("ending")

