# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 11:49:24 2019

@author: Administrator
"""

#Regulor Exp

import re
#find any number anywhere in the string
print(re.findall("\d+","3 pens cost 20 rupees and 50 paise"))
print(re.findall("\d","3 pens cost 20 rupees and 50 paise"))
#find any number at the begining of the string
print(re.findall("\d$","3 pens cost 20 rupees and 50 paise"))
print(re.findall("^\d+$","3 pens cost 20 rupees and 50 paise"))
#Split with multiple separaters
print(re.split("[,:-]", "Ramesh,223-rameshreddy@gmail.com"))

text = "My mobile number 9885970033. My atm pin in 5848"

print(re.sub(r'\d','*',text))
print(re.sub(r'\d+','*',text))

r=re.search('\d+',text)
print(r.group()) # group menas search first record 
print(r.span()) #span for find position starting and end of first record

#compiled regex
number= re.compile('\d+')
result=number.findall('He has 13 blue pens, 9 balls and 20 rupees')
print(result)
it=number.finditer("He has 13 blue pens, 9 balls, 6 books and 20 rupees")
for match in it:
    print(match.span())
    print(match.group())
    
print(re.sub(r'\sAND\s','&','A and B and C', flags=re.IGNORECASE))
#r means raw string
print(r'\sAND\s')
print('\sAND\s')