# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 16:36:56 2019

@author: Administrator
"""

from threading import Thread
def wish():
    print("Good evening")
t=Thread(target=wish)
t.start()
t.join()
