# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 16:21:11 2019

@author: Administrator
"""

import sys
from PyQt5.QtWidgets import QApplication, QLabel , QWidget,QLineEdit,QPushButton
app=QApplication(sys.argv)

window = QWidget()
window.setGeometry(100,100,300,150)
window.setWindowTitle("Square")

label_p = QLabel("Enter amount",window)
label_p.move(20, 10)

label_t = QLabel("Enter time",window)
label_t.move(20, 30)

label_r = QLabel("Enter rate",window)
label_r.move(20, 50)

textbox_p = QLineEdit(window)
textbox_p.move(100, 10)

textbox_t = QLineEdit(window)
textbox_t.move(100, 30)

textbox_r = QLineEdit(window)
textbox_r.move(100, 50)

textbox_result = QLineEdit(window)
textbox_result.move(100, 80)

def square():
    p=float(textbox_p.text())
    t=float(textbox_t.text())
    r=float(textbox_r.text())
    textbox_result.setText(str(p*t*r/100))

button = QPushButton('Compute Intertest', window)
button.move(100,100)
button.clicked.connect(square)

window.show()
app.exec_()
input("Press enter to quit")
