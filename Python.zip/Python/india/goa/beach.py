capital="Panaji"
beach="kalpatha"
