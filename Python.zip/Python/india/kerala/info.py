capital="Tiruvananthapuram"
animal="Elephant"
