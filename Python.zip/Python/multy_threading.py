# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 16:59:44 2019

@author: Administrator
"""

import subprocess
import queue
import time
from threading import Thread
import multiprocessing

cpu_count = multiprocessing.cpu_count()
print(cpu_count)
#if cpu_count == 1:
#    pool = multiprocessing.Pool(cpu_count)
#else:
#    pool = multiprocessing.Pool(cpu_count - 1)

ipfile = "ips1.txt"
myq=queue.Queue()
with open(ipfile,"r") as f:
    for myip in f:
        myq.put(myip.strip())

def myping(ip):
    return not subprocess.run(["ping", "-c", "1",ip],stdout=subprocess.PIPE).returncode


def worker():
    while not myq.empty():
        ip=myq.get()
        if myping(ip):
            print(ip, " is up")
        else:
            print(ip, " is down")
 
threads=[]
for x in range(10):
    threads.append(Thread(target=worker))
start=time.time()
for t in threads:
    t.start()
for t in threads:
    t.join()
end=time.time()  
print(end-start)