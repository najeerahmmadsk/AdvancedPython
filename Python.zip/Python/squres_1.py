# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 15:38:26 2019

@author: Administrator
"""
class Squres:
    def __init__(self, num):
        self.num = num
    def __iter__(self):
        self.counter = 0
        return self
    def __next__(self):
        """ Haee """
        if self.counter < self.num:
            output = self.counter **2
            self.counter += 1
        else:
            raise StopIteration
        return output
    def abc(self):
        """nannana"""
        return self
for x in Squres(5):
    print(x)
            
    
import antigravity