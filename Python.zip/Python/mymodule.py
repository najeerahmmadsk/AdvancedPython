# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 10:02:15 2019

@author: Administrator
"""

class Rectangle:
    def __init__(self,length,breadth):
        self.breadth=breadth
        self.length=length
    def getarea(self):
        return self.breadth*self.length
    def getperimeter(self):
        return 2*(self.length+self.breadth)
    
class Convert:
    def __init__(self,num):
        self.num=num
        self.cm = num*10
        self.mm = num*1000
        self.km = num/1000