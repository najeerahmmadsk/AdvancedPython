# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 15:13:52 2019

@author: Administrator
"""

#dictionary emulation
class Movie:
        def __init__(self):
            self._dict={}
        def __setitem__(self,key,value):
            self._dict[key]=value
        def __getitem__(self,key):
            return self._dict[key]
        def __iter__(self):
            self.roles=list(self._dict.keys())
            return self
        def __next__(self):
            if self.roles:
                role=self.roles.pop(0)
            else:
                raise StopIteration
            return role
            

bh=Movie()
bh['hero']="Prabhas"
bh['Director']='RM'
print(bh['hero'])

for role in bh:
    print(role,bh[role])
    
class Abc:
    pass
print(callable(Abc))
print(callable(len))
a=Abc()
print(callable(a))


from math import factorial
class Factorial:
    _cache={}
    def __call__(self,arg):
        if arg in Factorial._cache:
            print("getting from cache")
        else:
            Factorial._cache[arg] = factorial(arg)
        print(Factorial._cache[arg])
f1=Factorial()
f2=Factorial()
f3=Factorial()
f1(3)
f2(6)
f3(3) #getting from cache
f1(9)
f3(6) #getting from cache


