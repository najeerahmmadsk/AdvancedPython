# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 10:16:20 2019

@author: Administrator
"""
import os
class FileInfo:
    def __init__(self,filename):
        self.filename=filename
        self.f=open(self.filename,'r')
        self.lines=self.f.readlines()
    def getsize(self):
        print(os.path.getsize(self.filename))
    def getlinecount(self):
        print(len(self.lines))
    def firstline(self):
        print(self.nthline(1))
    def lastline(self):
        print(self.nthline(0))
    def nthline(self,lineno):
        print(self.lines[lineno-1])
    def search(self,pattern):
        for lineno,line in enumerate(self.lines):
            if pattern in line:
                print(lineno+1, line,end="")
    def close(self):
        self.f.close()




        