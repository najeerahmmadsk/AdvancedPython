# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 14:37:39 2019
http://garuda.pythonanywhere.com/
@author: Administrator
"""

from flask import Flask
import time
import requests
import sqlite3
app=Flask(__name__)
@app.route("/")
def wish():
    return "Hello from Flask"
@app.route("/calender")
def abc():
    return "day 4.one more day of torture"

@app.route("/now")
def time1():
    return str(time.ctime(time.time()))

@app.route("/hai/<name>")
def hai(name):
    return "Hello {}, Good Evening".format(name)

@app.route("/form")
def form():
	output = """
	<form action="/getbook" method=post>
	<input type=text name=title> Title<br>
	<input type=submit value="Search book">
	</form>
	"""
	return output
@app.route("/getbook",methods=["post"])
def book():
    a = requests.get("title")
    return a
@app.route("/books")
def getbook():
    cursor = sqlite3.connect("mydatabase.db").cursor()
    sql="select * from books"
    books=cursor.execute(sql).fetchall()
    output="<table border=1>"
    row="<tr><td>{}</td><td>{}</td><td>{}</td></tr>"
    for bid,title,author in books:
        output += row.format(bid,title,author)
    return output + "</table>"
if __name__ == '__main__':
   app.run(host="localhost", port=8000, debug=True)

