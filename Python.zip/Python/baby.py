# -*- coding: utf-8 -*-
"""
Created on Tue Jul  9 16:31:36 2019

@author: Administrator
"""

class Baby:
    def cry(self):
        print("I am crying")
    def laugh(self):
        print("ha.. ha.. ha")