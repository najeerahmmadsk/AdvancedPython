# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 16:05:02 2019

@author: Administrator
"""

import json
f=open("1.json", "r")
contents = f.read()
f.close()

data = json.loads(contents)
print(data.get("cities")[-1])

for x,y in data.items():
    print(x,y)
    
