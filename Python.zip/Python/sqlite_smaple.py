# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 12:23:37 2019

@author: Administrator
"""
import sqlite3
con=sqlite3.connect("mydatabase.db")
cursor=con.cursor()
#sql="""create table books(bid interger primary key,title text,author text)"""
#cursor.execute(sql)
#print("table created")
#con.close()
sql="""insert into book(title,author) values("wings of fire", "abdul kalam")"""
try:
    cursor.execute(sql)
except Exception as err:
    print(err)
    con.rollback()
else:
    con.commit()
    print("{} rows inserted".format(cursor.rowcount))
finally:
    con.close()

sql="""description books"""
cursor.execute(sql)
#print(cursor.fetchone())
#print(cursor.fetchmany(2))
#print(cursor.fetchall())
print(cursor.description)

con.close()