# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 09:52:50 2019

@author: Administrator
"""

from mymodule import Rectangle
a=Rectangle(5,9)
print(a.getarea())
print(a.getperimeter())

from mymodule import Convert
b=Convert(45)
print(b.cm)
print(b.mm)
print(b.km)